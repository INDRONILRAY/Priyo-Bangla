﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'cy', {
	anchor: 'Angor',
	flash: 'Animeiddiant Flash',
	hiddenfield: 'Maes Cudd',
	iframe: 'IFrame',
	unknown: 'Gwrthrych Anhysbys'
} );
