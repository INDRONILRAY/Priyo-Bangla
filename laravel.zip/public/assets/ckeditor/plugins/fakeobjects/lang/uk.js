﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'uk', {
	anchor: 'Якір',
	flash: 'Flash-анімація',
	hiddenfield: 'Приховані Поля',
	iframe: 'IFrame',
	unknown: 'Невідомий об\'єкт'
} );
